package forms;
import config.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class RepairOrderForm extends javax.swing.JFrame {
    
    private void loadCustomers() {

    try {

        Connection con = DBConnection.getConnection();

        String sql = "SELECT name FROM customers";

        PreparedStatement pst =
        con.prepareStatement(sql);

        ResultSet rs = pst.executeQuery();

        cbCustomer.removeAllItems();

        while(rs.next()) {

            cbCustomer.addItem(
                rs.getString("name")
            );

        }

    } catch (Exception e) {

        JOptionPane.showMessageDialog(this, e);

    }
}
    
    private void loadTechnicians() {

    try {

        Connection con = DBConnection.getConnection();

        String sql = "SELECT name FROM technicians";

        PreparedStatement pst =
        con.prepareStatement(sql);

        ResultSet rs = pst.executeQuery();

        cbTechnician.removeAllItems();

        while(rs.next()) {

            cbTechnician.addItem(
                rs.getString("name")
            );

        }

    } catch (Exception e) {

        JOptionPane.showMessageDialog(this, e);

    }
}
    
    private void loadServices() {

    try {

        Connection con = DBConnection.getConnection();

        String sql =
        "SELECT service_name FROM services";

        PreparedStatement pst =
        con.prepareStatement(sql);

        ResultSet rs = pst.executeQuery();

        cbService.removeAllItems();

        while(rs.next()) {

            cbService.addItem(
                rs.getString("service_name")
            );

        }

    } catch (Exception e) {

        JOptionPane.showMessageDialog(this, e);

    }
}
    
    private void saveOrder() {

    try {
        if(txtQuantity.getText().isEmpty()) {

    JOptionPane.showMessageDialog(
        this,
        "Quantity is required!"
    );

    return;
}

        Connection con = DBConnection.getConnection();

        // GET CUSTOMER ID
        String customerSQL =
        "SELECT customer_id FROM customers WHERE name=?";

        PreparedStatement customerPst =
        con.prepareStatement(customerSQL);

        customerPst.setString(
            1,
            cbCustomer.getSelectedItem().toString()
        );

        ResultSet customerRs =
        customerPst.executeQuery();

        int customerID = 0;

        if(customerRs.next()) {

            customerID =
            customerRs.getInt("customer_id");

        }

        // GET TECHNICIAN ID
        String techSQL =
        "SELECT technician_id FROM technicians WHERE name=?";

        PreparedStatement techPst =
        con.prepareStatement(techSQL);

        techPst.setString(
            1,
            cbTechnician.getSelectedItem().toString()
        );

        ResultSet techRs =
        techPst.executeQuery();

        int technicianID = 0;

        if(techRs.next()) {

            technicianID =
            techRs.getInt("technician_id");

        }

        // INSERT REPAIR ORDER
        String orderSQL =
        "INSERT INTO repair_orders(customer_id, technician_id, date_received, status) VALUES (?, ?, NOW(), ?)";

        PreparedStatement orderPst =
        con.prepareStatement(
            orderSQL,
            PreparedStatement.RETURN_GENERATED_KEYS
        );

        orderPst.setInt(1, customerID);

        orderPst.setInt(2, technicianID);

        orderPst.setString(
            3,
            cbStatus.getSelectedItem().toString()
        );

        orderPst.executeUpdate();

        ResultSet generatedKeys =
        orderPst.getGeneratedKeys();

        int orderID = 0;

        if(generatedKeys.next()) {

            orderID = generatedKeys.getInt(1);

        }

        // GET SERVICE ID
        String serviceSQL =
        "SELECT service_id, price FROM services WHERE service_name=?";

        PreparedStatement servicePst =
        con.prepareStatement(serviceSQL);

        servicePst.setString(
            1,
            cbService.getSelectedItem().toString()
        );

        ResultSet serviceRs =
        servicePst.executeQuery();

        int serviceID = 0;

        double price = 0;

        if(serviceRs.next()) {

            serviceID =
            serviceRs.getInt("service_id");

            price =
            serviceRs.getDouble("price");

        }

        int quantity =
        Integer.parseInt(txtQuantity.getText());

        double subtotal =
        quantity * price;

        txtSubtotal.setText(
            String.valueOf(subtotal)
        );

        // INSERT ORDER DETAILS
        String detailSQL =
        "INSERT INTO repair_order_details(order_id, service_id, quantity, subtotal) VALUES (?, ?, ?, ?)";

        PreparedStatement detailPst =
        con.prepareStatement(detailSQL);

        detailPst.setInt(1, orderID);

        detailPst.setInt(2, serviceID);

        detailPst.setInt(3, quantity);

        detailPst.setDouble(4, subtotal);

        detailPst.executeUpdate();

        JOptionPane.showMessageDialog(
            this,
            "Order Saved Successfully!"
        );

        loadOrders();

    } catch (Exception e) {

        JOptionPane.showMessageDialog(this, e);

    }
}
    
    private void loadOrders() {

    try {

        Connection con = DBConnection.getConnection();

        String sql =
        "SELECT ro.order_id, c.name AS customer, t.name AS technician, s.service_name, rod.quantity, rod.subtotal, ro.status " +
        "FROM repair_orders ro " +
        "JOIN customers c ON ro.customer_id = c.customer_id " +
        "JOIN technicians t ON ro.technician_id = t.technician_id " +
        "JOIN repair_order_details rod ON ro.order_id = rod.order_id " +
        "JOIN services s ON rod.service_id = s.service_id";

        PreparedStatement pst =
        con.prepareStatement(sql);

        ResultSet rs = pst.executeQuery();

        DefaultTableModel model =
        (DefaultTableModel) tblOrders.getModel();

        model.setRowCount(0);

        while(rs.next()) {

            model.addRow(new Object[] {

                rs.getInt("order_id"),
                rs.getString("customer"),
                rs.getString("technician"),
                rs.getString("service_name"),
                rs.getInt("quantity"),
                rs.getDouble("subtotal"),
                rs.getString("status")

            });

        }

    } catch (Exception e) {

        JOptionPane.showMessageDialog(this, e);

    }
}
    private void deleteOrder() {

    try {

        if(txtOrderID.getText().isEmpty()) {

            JOptionPane.showMessageDialog(
                this,
                "Please select an order first!"
            );

            return;
        }

        int confirm =
        JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to delete this order?"
        );

        if(confirm == 0) {

            Connection con =
            DBConnection.getConnection();

            int orderID =
            Integer.parseInt(txtOrderID.getText());

            // DELETE CHILD RECORDS FIRST
            String detailSQL =
            "DELETE FROM repair_order_details WHERE order_id=?";

            PreparedStatement detailPst =
            con.prepareStatement(detailSQL);

            detailPst.setInt(1, orderID);

            detailPst.executeUpdate();

            // DELETE MAIN ORDER
            String orderSQL =
            "DELETE FROM repair_orders WHERE order_id=?";

            PreparedStatement orderPst =
            con.prepareStatement(orderSQL);

            orderPst.setInt(1, orderID);

            orderPst.executeUpdate();

            JOptionPane.showMessageDialog(
                this,
                "Order Deleted Successfully!"
            );

            loadOrders();

            clearFields();
        }

    } catch (Exception e) {

        e.printStackTrace();

        JOptionPane.showMessageDialog(this, e);

    }
}
    private void clearFields() {

    txtOrderID.setText("");

    txtQuantity.setText("");

    txtSubtotal.setText("");

}
    
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(RepairOrderForm.class.getName());

    /**
     * Creates new form RepairOrderForm
     */
    public RepairOrderForm() {
        initComponents();
        loadCustomers();
        loadTechnicians();
        loadServices();
        loadOrders();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txtOrderID = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtQuantity = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtSubtotal = new javax.swing.JTextField();
        cbCustomer = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cbTechnician = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        cbService = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        cbStatus = new javax.swing.JComboBox<>();
        btnSave = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblOrders = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("OrderID");

        jLabel2.setText("Quantity");

        jLabel3.setText("Subtotal");

        cbCustomer.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel4.setText("Costumer");

        jLabel5.setText("Technician");

        cbTechnician.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel6.setText("Service");

        cbService.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel7.setText("Status");

        cbStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pending", "Completed", "Released" }));

        btnSave.setText("Save");
        btnSave.addActionListener(this::btnSaveActionPerformed);

        btnDelete.setText("Delete");
        btnDelete.addActionListener(this::btnDeleteActionPerformed);

        tblOrders.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Order ID", "Customer", "Technician", "Service", "Quantity", "Subtotal", "Status"
            }
        ));
        tblOrders.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblOrdersMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblOrders);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(18, 18, 18)
                                .addComponent(txtOrderID, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtQuantity)
                                    .addComponent(txtSubtotal))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7))
                                .addGap(39, 39, 39))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(24, 24, 24))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(cbCustomer, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cbStatus, javax.swing.GroupLayout.Alignment.LEADING, 0, 0, Short.MAX_VALUE)
                            .addComponent(cbTechnician, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cbService, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(140, 140, 140)
                                .addComponent(btnSave)
                                .addGap(70, 70, 70)
                                .addComponent(btnDelete)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtOrderID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2)
                        .addComponent(txtQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cbTechnician, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3)
                        .addComponent(txtSubtotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel6))
                    .addComponent(cbService, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(cbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSave)
                    .addComponent(btnDelete))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed
    saveOrder();
    }//GEN-LAST:event_btnSaveActionPerformed

    private void tblOrdersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblOrdersMouseClicked
    int row = tblOrders.getSelectedRow();

txtOrderID.setText(
    tblOrders.getValueAt(row, 0).toString()
);
    }//GEN-LAST:event_tblOrdersMouseClicked

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
    deleteOrder();   
    }//GEN-LAST:event_btnDeleteActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new RepairOrderForm().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnSave;
    private javax.swing.JComboBox<String> cbCustomer;
    private javax.swing.JComboBox<String> cbService;
    private javax.swing.JComboBox<String> cbStatus;
    private javax.swing.JComboBox<String> cbTechnician;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblOrders;
    private javax.swing.JTextField txtOrderID;
    private javax.swing.JTextField txtQuantity;
    private javax.swing.JTextField txtSubtotal;
    // End of variables declaration//GEN-END:variables
}
